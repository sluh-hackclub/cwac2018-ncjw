#!/bin/bash

pyclean
# http://stackoverflow.com/a/22916141
