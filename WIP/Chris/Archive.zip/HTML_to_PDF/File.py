import os
import pdfkit

pdfkit.from_file('/Users/chrisj/Desktop/SLUH_Study/Hackathon/HTML_to_PDF/SAMPLE.html', '/Users/chrisj/Desktop/SLUH_Study/Hackathon/HTML_to_PDF/OUTPUT.pdf')
